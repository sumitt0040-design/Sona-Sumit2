Sona ❤️ Sumit — Cinematic Proposal V3

Upload index.html, sona.jpg and sumit.jpg to the root of your GitHub repository.

Optional music: add a legally obtained MP3 named song.mp3 to the same folder. The site will attempt to play it after the visitor taps OPEN MY HEART.

This version changes the message so it does NOT say that Sona has already fallen in love with Sumit. It is written as an honest proposal/date request.
